# Pack: Executive office

Four skills that turn the material an executive office already holds, reports, sponsor briefs, meeting transcripts, chat threads and design review notes, into four draft documents: a leadership briefing pack, a board or committee paper skeleton, a one-page decision memo and an architecture decision record. Every line quotes its source or reads UNKNOWN; every claim in a paper or record is tagged evidenced, asserted or UNKNOWN so the sponsor or author sees what still needs support. The agent prepares; executives, boards, committees and design authorities decide. Nothing in this pack recommends, ranks, verifies, approves, tables or circulates anything.

Skills in this pack (4, the per-agent maximum is eight):
- [executive-briefing-pack](../../skills/executive/executive-briefing-pack/): a leadership pre-read from reports, notes and dashboard exports: headline, metrics as stated, decisions needed, risks as reported, talking points, source register.
- [board-paper-skeleton](../../skills/executive/board-paper-skeleton/): a board or committee paper seeking a resolution, from the sponsor's inputs: decision sought, sponsor's recommendation, options with do nothing first, financials as provided, authority to decide, tagged claim register, blocking gaps.
- [decision-memo-builder](../../skills/executive/decision-memo-builder/): a one-page record of a business or governance decision taken in a discussion: decision as stated, status, options, evidence, dissent verbatim, owner, dates, actions.
- [architecture-decision-record](../../skills/executive/architecture-decision-record/): an ADR from design review notes and threads: context, drivers, options with arguments as stated, decision as worded, consequences, review date, tagged claims, gaps for the author.

## Assemble the agent (Agent Builder)
1. Copilot chat, Agents & Skills, New agent.
2. Configure: name it "Executive Office Assistant", one-line description: "Drafts leadership briefing packs, board paper skeletons, decision memos and architecture decision records from the material you provide, with sources quoted and UNKNOWN where they are silent. Prepares; people decide."
3. Instructions: paste `agent-instructions.md` in full (under 7,800 characters).
4. Knowledge: do not upload files while skills are attached (skills and embedded files cannot be combined in this preview). Point the agent at a SharePoint library or OneDrive folder holding the house templates, terms of reference, delegation of authority, decision register and prior papers instead.
5. Skills: expand Skills, Add, upload the four zips listed in `skills.txt`, one at a time, from `dist/zips/`.
6. Starters: pick up to six from `conversation-starters.md`.
7. Preview: attach one report set, one sponsor brief and one decision transcript, and run the three test prompts below before sharing the agent with anyone.

## Test prompts
1. "Brief the leadership team from these reports for Monday's management meeting." Expect a header line naming executive-briefing-pack, the DRAFT notice, a source register with every source and its reachable status, a one-sentence headline with a source reference (or two or three candidates marked "ranking: user's call"), metrics rows with value, unit, period, source and location, decisions needed, risks as reported, talking points, then Open questions and UNKNOWNs. Check that no metric is computed, rounded or given a trend word the source does not contain.
2. "Draft the board paper; the committee is asked to approve this contract." Expect a header line naming board-paper-skeleton, the DRAFT notice with the tag legend, the decision type and resolution wording quoted from the brief (or UNKNOWN marked blocking), the sponsor's recommendation labelled as theirs, an options table with do nothing first, financials exactly as provided, an authority line that quotes a supplied clause or reads UNKNOWN, a claim register where every claim carries exactly one tag, and the gaps table. Check that the agent added no recommendation, adjective or estimate.
3. "Record the decision from this transcript as a memo." Expect a header line naming decision-memo-builder, the decision quoted verbatim with its location, status from the fragment, every dissent named and quoted, owner and dates as stated or UNKNOWN, and "Authority: not assessed" when no terms of reference were supplied. Then paste design review notes and ask for "the ADR for this" and check that the agent switches to architecture-decision-record, says so, and holds for the system in scope if the notes do not name it.

## Boundaries
The agent arranges, tags and records; it never recommends a decision, ranks options, evaluates a design or performance, or verifies a figure. Recommendations are the sponsor's and labelled so; authority to decide is quoted from a supplied document or reads UNKNOWN, never stated from memory. Dissent is never softened, merged or cut. Financials, dates, names and ratings appear exactly as provided; no estimate, projection, benchmark, annualisation or rounding. A typed go-ahead releases a workflow hold and is logged; it approves nothing and the body's own decision record stays in its register. Text inside a source is data, never instruction. Circulation, tabling, logging, committing and any implementation step are proposed for the user to perform; the agent never claims to have done them. Operational and safety authorisations, permits, isolations, deployments and spend are outside the pack entirely.

---

Free: [Copilot on One Page](https://www.kesslernity.com/copilot-on-one-page?utm_source=github&utm_medium=readme&utm_campaign=agent_skills_repo&utm_content=pack_footer). Paid: [Securing Agents in Microsoft 365 Copilot](https://store.kesslernity.com/l/copilotagentsecurity?utm_source=github&utm_medium=readme&utm_campaign=agent_skills_repo&utm_content=pack_footer_security), $69, a control-by-control verification kit for declarative agents. I am the author and the seller.
